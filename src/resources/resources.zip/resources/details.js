/*
  Requirement: Populate the resource detail page and discussion forum.

  Instructions:
  1. Link this file to `details.html` using:
     <script src="details.js" defer></script>

  2. In `details.html`, add the following IDs:
     - To the <h1>: `id="resource-title"`
     - To the description <p>: `id="resource-description"`
     - To the "Access Resource Material" <a> tag: `id="resource-link"`
     - To the <div> for comments: `id="comment-list"`
     - To the "Leave a Comment" <form>: `id="comment-form"`
     - To the <textarea>: `id="new-comment"`

  3. Implement the TODOs below.
*/ 

// --- Global Data Store ---
let currentResourceId = null;
let currentComments = [];

// --- Element Selections ---
const resourceTitle = document.querySelector('#resource-title');
const resourceDescription = document.querySelector('#resource-description');
const resourceLink = document.querySelector('#resource-link');
const commentList = document.querySelector('#comment-list');
const commentForm = document.querySelector('#comment-form');
const newComment = document.querySelector('#new-comment');

// --- Functions ---

/**
 * Get the 'id' parameter from the URL
 */
function getResourceIdFromURL() {
    const params = new URLSearchParams(window.location.search);
    return params.get('id');
}

/**
 * Render resource details
 */
function renderResourceDetails(resource) {
    resourceTitle.textContent = resource.title;
    resourceDescription.textContent = resource.description;
    resourceLink.href = resource.link;
}

/**
 * Create a comment <article> element
 */
function createCommentArticle(comment) {
    const article = document.createElement('article');

    const p = document.createElement('p');
    p.textContent = comment.text;

    const footer = document.createElement('footer');
    footer.innerHTML = `<small>Posted by: <strong>${comment.author}</strong> on ${new Date(comment.created_at).toLocaleDateString()}</small>`;

    article.appendChild(p);
    article.appendChild(footer);

    return article;
}

/**
 * Render the list of comments
 */
function renderComments() {
    commentList.innerHTML = '';
    currentComments.forEach(comment => {
        const article = createCommentArticle(comment);
        commentList.appendChild(article);
    });
}

/**
 * Handle Add Comment form submission
 */
async function handleAddComment(event) {
    event.preventDefault();
    const commentText = newComment.value.trim();
    if (!commentText) return;

    try {
        const response = await fetch('api/index.php?action=comment', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                resource_id: currentResourceId,
                author: 'Student', // TODO: Get from session/auth
                text: commentText
            })
        });

        const json = await response.json();

        if (!json.success) {
            alert('Error: ' + (json.message || 'Failed to post comment'));
            return;
        }

        // Reload comments from server
        await loadComments();

        // Clear form
        newComment.value = '';
        alert('Comment posted successfully!');
    } catch (error) {
        console.error('Error posting comment:', error);
        alert('Failed to post comment. Please try again.');
    }
}

/**
 * Load comments for the current resource
 */
async function loadComments() {
    try {
        const response = await fetch(`api/index.php?action=comments&resource_id=${currentResourceId}`);
        const json = await response.json();

        if (!json.success) {
            throw new Error(json.message || 'Failed to load comments');
        }

        currentComments = json.data || [];
        renderComments();
    } catch (error) {
        console.error('Error loading comments:', error);
        commentList.innerHTML = '<p>Failed to load comments.</p>';
    }
}

/**
 * Initialize the page
 */
async function initializePage() {
    currentResourceId = getResourceIdFromURL();

    if (!currentResourceId) {
        resourceTitle.textContent = "Resource not found.";
        return;
    }

    try {
        // Fetch resource details
        const response = await fetch(`api/index.php?id=${currentResourceId}`);
        const json = await response.json();

        if (!json.success) {
            resourceTitle.textContent = "Resource not found.";
            return;
        }

        const resource = json.data;
        renderResourceDetails(resource);

        // Load comments
        await loadComments();

        // Add event listener for comment form
        commentForm.addEventListener('submit', handleAddComment);
    } catch (error) {
        console.error('Error initializing page:', error);
        resourceTitle.textContent = "Failed to load resource.";
    }
}

// --- Initial Page Load ---
initializePage();
