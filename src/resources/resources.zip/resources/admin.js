/*
  Requirement: Make the "Manage Resources" page interactive.

  Instructions:
  1. Link this file to `admin.html` using:
     <script src="admin.js" defer></script>
  
  2. In `admin.html`, add an `id="resources-tbody"` to the <tbody> element
     inside your `resources-table`.
  
  3. Implement the TODOs below.
*/// --- Global Data Store ---
let resources = [];

// --- Element Selections ---
const resourceForm = document.querySelector('#resource-form');
const resourcesTableBody = document.querySelector('#resources-tbody');
 
// --- Functions ---

/**
 * Create a table row (<tr>) for a resource object
 */
function createResourceRow(resource) {
    const tr = document.createElement('tr');

    // Title TD
    const titleTd = document.createElement('td');
    titleTd.textContent = resource.title;
    tr.appendChild(titleTd);

    // Description TD
    const descTd = document.createElement('td');
    descTd.textContent = resource.description;
    tr.appendChild(descTd);

    // Actions TD
    const actionsTd = document.createElement('td');

    // Edit button
    const editBtn = document.createElement('button');
    editBtn.textContent = 'Edit';
    editBtn.classList.add('edit-btn');
    editBtn.setAttribute('data-id', resource.id);
    actionsTd.appendChild(editBtn);

    // Delete button
    const deleteBtn = document.createElement('button');
    deleteBtn.textContent = 'Delete';
    deleteBtn.classList.add('delete-btn');
    deleteBtn.setAttribute('data-id', resource.id);
    actionsTd.appendChild(deleteBtn);

    tr.appendChild(actionsTd);

    return tr;
}

/**
 * Render the resources table
 */
function renderTable() {
    // Clear the table body
    resourcesTableBody.innerHTML = '';

    // Loop through resources and append rows
    resources.forEach(resource => {
        const tr = createResourceRow(resource);
        resourcesTableBody.appendChild(tr);
    });
}

/**
 * Handle Add Resource form submission
 */
async function handleAddResource(event) {
    event.preventDefault();

    // Get input values
    const title = document.querySelector('#resource-title').value.trim();
    const description = document.querySelector('#resource-description').value.trim();
    const link = document.querySelector('#resource-link').value.trim();

    if (!title || !link) return; // required fields

    try {
        const response = await fetch('api/index.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ title, description, link })
        });

        const json = await response.json();

        if (!json.success) {
            alert('Error: ' + (json.message || 'Failed to create resource'));
            return;
        }

        // Reload resources from server
        await loadAndInitialize();

        // Reset form
        resourceForm.reset();
        alert('Resource added successfully!');
    } catch (error) {
        console.error('Error adding resource:', error);
        alert('Failed to add resource. Please try again.');
    }
}

/**
 * Handle clicks on the resources table (delegation)
 */
async function handleTableClick(event) {
    const target = event.target;

    // Delete functionality
    if (target.classList.contains('delete-btn')) {
        const id = target.getAttribute('data-id');

        if (!confirm('Are you sure you want to delete this resource?')) {
            return;
        }

        try {
            const response = await fetch(`api/index.php?id=${id}`, {
                method: 'DELETE'
            });

            const json = await response.json();

            if (!json.success) {
                alert('Error: ' + (json.message || 'Failed to delete resource'));
                return;
            }

            // Reload resources from server
            await loadAndInitialize();
            alert('Resource deleted successfully!');
        } catch (error) {
            console.error('Error deleting resource:', error);
            alert('Failed to delete resource. Please try again.');
        }
    }

    // Optional: Edit functionality could be implemented here
}

/**
 * Load resources from API and initialize event listeners
 */
async function loadAndInitialize() {
    try {
        // Fetch the resources from API
        const response = await fetch('api/index.php');
        const json = await response.json();

        if (!json.success) {
            throw new Error(json.message || 'Failed to load resources');
        }

        // Store in global array
        resources = json.data || [];

        // Initial render
        renderTable();

        // Event listeners (only add once)
        if (!resourceForm.dataset.listenerAdded) {
            resourceForm.addEventListener('submit', handleAddResource);
            resourceForm.dataset.listenerAdded = 'true';
        }
        if (!resourcesTableBody.dataset.listenerAdded) {
            resourcesTableBody.addEventListener('click', handleTableClick);
            resourcesTableBody.dataset.listenerAdded = 'true';
        }
    } catch (error) {
        console.error('Error loading resources:', error);
        alert('Failed to load resources. Please refresh the page.');
    }
}

// --- Initial Page Load ---
loadAndInitialize();
